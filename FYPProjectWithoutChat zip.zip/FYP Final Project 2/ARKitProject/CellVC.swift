//
//  CellVC.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 26/02/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class CellVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}
