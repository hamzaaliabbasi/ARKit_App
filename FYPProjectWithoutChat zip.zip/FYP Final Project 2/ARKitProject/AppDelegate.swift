import UIKit
import Firebase
import IQKeyboardManagerSwift
import SWRevealViewController
@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
	var window: UIWindow?
    
    
    
    
    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?)
        -> Bool {
                IQKeyboardManager.shared.enable = true
            FirebaseApp.configure()
      
            
            if(Auth.auth().currentUser?.uid == nil){
                let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginNavigator") as! UINavigationController
                window?.rootViewController = vc}
                else
                {
                    let vc =  UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SWRevealViewController") as? SWRevealViewController
                        window?.rootViewController = vc
            
                    
                }
            
            return true
    }
    
}
