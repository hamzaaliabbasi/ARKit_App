//
//  ship.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 30/06/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

class ship: VirtualObject {
    
    override init() {
        super.init(modelName: "ship", fileExtension: "scn", thumbImageFilename: "icons8-airplane-landing-50", title: "ship")
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
