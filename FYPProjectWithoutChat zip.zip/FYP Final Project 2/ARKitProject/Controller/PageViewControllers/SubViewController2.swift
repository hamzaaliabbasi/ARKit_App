//
//  SubViewController2.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 27/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class SubViewController2: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

  

}
