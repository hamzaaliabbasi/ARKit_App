//
//  SubViewController1.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 18/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class SubViewController1: UIViewController {

    @IBOutlet weak var scroll: UIPageControl!
    
    @IBOutlet weak var textfield: UITextField!
    
    @IBOutlet weak var image: UIImageView!
    
    
    @IBAction func next(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()

      
       
    }
    


 
  
    
}
