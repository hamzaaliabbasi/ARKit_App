//
//  PageViewController.swift
//  simpleApp
//
//  Created by Tpl Life 02 on 18/03/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit

class PageViewController:  UIPageViewController,UIScrollViewDelegate {
    var currentIndex:Int?// for uipagecontroll current page indicator
    var scroll = UIPageControl()
    static var currentVC:UIViewController?
    let page1 = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SubViewController1") as! SubViewController1
    let page2 = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SubViewController2") as! SubViewController2
    let page3 = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SubViewController3") as! SubViewController3
    lazy var SubViewControllers : [UIViewController] = {return [page1,page2,page3]}()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        setViewControllers([SubViewControllers[0]], direction: .forward, animated: false, completion: nil)
        PageViewController.currentVC = SubViewControllers[0]
        self.delegate = self as UIPageViewControllerDelegate
        self.dataSource = self as UIPageViewControllerDataSource
        currentIndex = 0
        
        addScroll()
        addNextbutton()
        addSkipButton()
   
        
        
    }
}
extension PageViewController: UIPageViewControllerDelegate,UIPageViewControllerDataSource{
    func presentationCount(for pageViewController: UIPageViewController) -> Int {
        return SubViewControllers.count
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        let index:Int = SubViewControllers.index(of: viewController) ?? 0
        if(index <= 0)
        {
            return nil
        }
        else{
            PageViewController.currentVC = SubViewControllers[index - 1]
            print( PageViewController.currentVC!)
            currentIndex = index - 1
            scroll.currentPage = currentIndex!
            return SubViewControllers[index - 1]
        }}
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        let index: Int = SubViewControllers.index(of: viewController) ?? 0
        if(index >= SubViewControllers.count - 1)
        {return nil}
        else{
            PageViewController.currentVC = SubViewControllers[index + 1]
            print(  PageViewController.currentVC!)
            currentIndex = index + 1
            scroll.currentPage = currentIndex!
            return SubViewControllers[index + 1]
            
        }}
    func addNextbutton()
    {
        var button = UIButton()
    
        button.setTitle("Next", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.frame = CGRect(x: self.view.frame.size.width - 70, y: self.view.frame.size.height - 80, width: 50, height: 50)
        button.addTarget(self, action: #selector(PageViewController.present(sender:)), for: .touchUpInside)
        self.view.addSubview(button)
        self.view.bringSubview(toFront: button)
        button.isMultipleTouchEnabled = false
    }
    func addBackButton()
    {
        var button = UIButton()
        
        button.setTitle("Back", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.frame = CGRect(x: 30, y: self.view.frame.size.height - 80, width: 70, height: 50)
        button.addTarget(self, action: #selector(PageViewController.Secondpresent(sender:)), for: .touchUpInside)
        self.view.addSubview(button)
        self.view.bringSubview(toFront: button)
        button.isMultipleTouchEnabled = false
    }
    func addSkipButton()
    {     let button = UIButton()
        
        button.setTitle("Skip", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.frame = CGRect(x: 5, y: 35, width: 35, height: 50)
        button.addTarget(self, action: #selector(PageViewController.SkipPressed(sender:)), for: .touchUpInside)
        self.view.addSubview(button)
        self.view.bringSubview(toFront: button)
        button.isMultipleTouchEnabled = false
        
    }
    func addScroll() {
        
        scroll.frame = CGRect(x: (self.view.frame.width / 2) - 25, y: self.view.frame.size.height - 80, width: 50, height: 50)
        scroll.numberOfPages = 3
        
        scroll.currentPage = currentIndex!
        scroll.pageIndicatorTintColor = UIColor.gray
        scroll.currentPageIndicatorTintColor = UIColor.blue
        self.view.addSubview(scroll)
        
    }
    @objc func SkipPressed(sender:UIButton)
    {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
        self.present(vc, animated: false, completion: nil)
        
    }
    
    @objc func present(sender:UIButton)
    {
        switch PageViewController.currentVC{
        case SubViewControllers[0]:
            addBackButton()
            PageViewController.currentVC = SubViewControllers[1]
            currentIndex = 1
            scroll.currentPage = currentIndex!
            getNextVC(newIndex: SubViewControllers[1])
            
            break
        case SubViewControllers [1]:
            addBackButton()
            PageViewController.currentVC = SubViewControllers[2]
            currentIndex = 2
            scroll.currentPage = currentIndex!
            getNextVC(newIndex: SubViewControllers[2])
            break
        case SubViewControllers [2]:
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
            self.present(vc, animated: false, completion: nil)
            
            break
        case .none:
            return
        case .some(_):
            return
        }
    }
    @objc func Secondpresent(sender:UIButton)
    {
        
        
        switch PageViewController.currentVC{
        case SubViewControllers[2]:
              sender.isHidden = true
            currentIndex = 1
            scroll.currentPage = currentIndex!
            PageViewController.currentVC = SubViewControllers[1]
            getNextVC(newIndex: SubViewControllers[1])
            break
        case SubViewControllers [1]:
            sender.isHidden = true
            currentIndex = 0
            scroll.currentPage = currentIndex!
            PageViewController.currentVC = SubViewControllers[0]
            getNextVC(newIndex: SubViewControllers[0])
            break
//        case SubViewControllers [0]:
//       sender.isHidden = true
            break
        case .none:
            return
        case .some(_):
            return
        }
    }
    
    func getNextVC(newIndex: UIViewController){
      
        setViewControllers([newIndex], direction: UIPageViewController.NavigationDirection.forward, animated: false, completion: nil)
    }
    
}



