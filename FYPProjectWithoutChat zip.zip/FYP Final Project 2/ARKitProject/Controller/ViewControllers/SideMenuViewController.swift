//
//  SideMenuViewController.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 18/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import Firebase
import  SWRevealViewController


class SideMenuViewController: UIViewController {
    
    //MARK: - Global Variables
   let appdele = UIApplication.shared.delegate  as! AppDelegate
    let list = ["Home","My Ads","Logout"]
    let icon = ["nav_home","title","nav_logout"]
    //MARK: - Outlets
    
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var lbl_userEmail: UILabel!
    @IBOutlet weak var lbl_userName: UILabel!
    @IBOutlet weak var img_profile: UIImageView!
    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        img_profile.clipsToBounds = true
        img_profile.cornerRadius = img_profile.bounds.size.width * 0.5
        table.tableFooterView = UIView()
        self.lbl_userName.text = UserDefaults.standard.string(forKey: "User_Name")
        self.lbl_userEmail.text = UserDefaults.standard.string(forKey: "User_Email")
        if  let url = UserDefaults.standard.string(forKey: "User_ProfilePic"){
            helper.sharedInstance.setImageWithSDWebImage(imageView: self.img_profile, url: url)
       }
        
    }
    
  


}

extension SideMenuViewController:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SWTableViewCell") as! SWTableViewCell
        
        cell.LogoImage.image = UIImage(named: self.icon[indexPath.row])
        cell.LogoLabel.text = self.list[indexPath.row]
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        switch indexPath.row {
            
        case 0 :
                    let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SWRevealViewController") as! SWRevealViewController
                    
                    let sw = self.revealViewController()
                    sw?.pushFrontViewController(vc, animated: true)
            
            self.revealViewController()?.revealToggle(animated: true)
            
        case 2:            self.revealViewController()?.revealToggle(animated: true)
            
            let Alert = UIAlertController(title: "Logout", message: "Are you sure that you want to logout?", preferredStyle: .alert)
            
            
            let alert_Action = UIAlertAction(title: "Confirm", style: .default, handler: {(alert: UIAlertAction!) in
                //loging out
                do {
                    try Auth.auth().signOut()
                    
                } catch (let error) {
                    print((error as NSError).code)
                }
                //removing user deafults
                if let appDomain = Bundle.main.bundleIdentifier {
                    UserDefaults.standard.removePersistentDomain(forName: appDomain)
                }
            helper.sharedInstance.myAds.removeAll()
                
                
                let vc =  UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LoginNavigator") as? UINavigationController
                self.appdele.window?.rootViewController = vc
                
                
                self.dismiss(animated: false, completion: nil)})//handler
            
            Alert.addAction(alert_Action)
            Alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
            self.present(Alert, animated: true, completion: nil)
        case 1 :
            
            let sw = self.revealViewController()
            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MyAdNavigationController") as! UINavigationController
            sw?.pushFrontViewController(vc, animated: true)
            
            
        default:
            do {
                try Auth.auth().signOut()
                
            } catch (let error) {
                print((error as NSError).code)
            }
        }
    }
    
    
}
