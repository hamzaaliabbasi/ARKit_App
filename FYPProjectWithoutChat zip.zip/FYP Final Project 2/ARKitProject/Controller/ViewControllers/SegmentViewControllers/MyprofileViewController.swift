//
//  ProfileViewController.swift
//  ToyotaClientApp
//
//  Created by Tpl Life 02 on 10/06/2019.
//  Copyright © 2019 Tpl Life 02. All rights reserved.
//

import UIKit
//import SWRevealViewController
class MyprofileViewController: UIViewController {
    
    
    //MARK: - Global Variables
    var toolBar = UIToolbar()
    var picker  = UIPickerView()
   
    let imageTakingTypes = ["Gallery","Camera"]
    var picTakingType = 0
    
    //MARK: - Outlets
    
    @IBOutlet weak var txt_name: UITextField!
    @IBOutlet weak var txt_number: UITextField!
    @IBOutlet weak var txt_address: UITextField!
    @IBOutlet weak var txt_email: UITextField!
    @IBOutlet weak var Btn_Edit: UIButton!
    
    @IBOutlet weak var pickImage: UIButton!
    
    @IBOutlet weak var img_image: UIImageView!
    //MARK: - ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.txt_name.placeholder = UserDefaults.standard.string(forKey: "User_Name")
        self.txt_email.placeholder = UserDefaults.standard.string(forKey: "User_Email")
        if  let url = UserDefaults.standard.string(forKey: "User_ProfilePic"){
            helper.sharedInstance.setImageWithSDWebImage(imageView: self.img_image, url: url)
          }
        self.txt_number.placeholder = UserDefaults.standard.string(forKey: "User_Contact")
        self.txt_address.placeholder = UserDefaults.standard.string(forKey: "User_Address")

        self.img_image.cornerRadius = 0.5 * img_image.bounds.size.width
        self.Btn_Edit.clipsToBounds = true
        self.Btn_Edit.cornerRadius = 0.5 * Btn_Edit.bounds.size.width
        
        
    }//ViewDidLoad Ends
    
    
    //MARK: - Actions
    
    @IBAction func edit(_ sender: Any) {
        txt_name.isEnabled = true
        txt_email.isEnabled = true
        txt_address.isEnabled = true
        txt_number.isEnabled = true
        pickImage.isEnabled = true
        
        txt_name.text = txt_name.placeholder
        txt_email.text = txt_email.placeholder
        txt_address.text = txt_address.placeholder
        txt_number.text = txt_number.placeholder
        
        txt_name.becomeFirstResponder()
        
    }
    @IBAction func update_btn(_ sender: Any) {
      
    }
    
    
    
    
    @IBAction func pickImage(_ sender: Any) {
        picker = UIPickerView.init()
        picker.delegate = self
        picker.backgroundColor = UIColor.white
        picker.setValue(UIColor.black, forKey: "textColor")
        picker.autoresizingMask = .flexibleWidth
        picker.contentMode = .center
        picker.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 350, width: UIScreen.main.bounds.size.width, height: 350)
        self.view.addSubview(picker)
        
        toolBar = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 350, width: UIScreen.main.bounds.size.width, height: 50))
        toolBar.barStyle = .blackTranslucent
        toolBar.items = [UIBarButtonItem.init(title: "Done", style: .done, target: self, action: #selector(onDoneButtonTapped))]
        self.view.addSubview(toolBar)
    }
    
    
    //MARK: - Functions
    
    @objc func onDoneButtonTapped(){
        toolBar.removeFromSuperview()
        picker.removeFromSuperview()
        
    }
}
extension MyprofileViewController: UIImagePickerControllerDelegate,UINavigationControllerDelegate
{
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let pickedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        //imageView.contentMode = .scaleAspectFit
        
        self.img_image.image = pickedImage
        
        dismiss(animated: true, completion: nil)
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}


extension MyprofileViewController: UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return  1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
         return imageTakingTypes.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
      return imageTakingTypes[row]
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        if(row == 0)
        {
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
                var imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .photoLibrary;
                imagePicker.allowsEditing = false
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
        else
        {
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                var imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .camera;
                imagePicker.allowsEditing = false
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
        
        
    
        
}

}
