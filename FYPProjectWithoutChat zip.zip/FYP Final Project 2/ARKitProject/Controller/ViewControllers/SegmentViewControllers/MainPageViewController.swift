//
//  MainPageViewController.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 13/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField

class MainPageViewController: UIViewController {
    
    //MARK: - Global Variables
    var searchedCategory = ""
    var searched = false
    var refreshControl = UIRefreshControl()
    var popUpView = popOn.instanceFromNib()
    let pickerView = UIPickerView()
    let titles = ["Candle","Cup","Vase","Lamp","Chair","Ship"]
    
let descr = ["Amazing","Nice","average","Good","Excellent","average"]
    
 let prices = ["Rs 1550","Rs 2000","Rs 5000","Rs 1000","Rs 50000","Rs 5000"]
   
 let locations = ["Bufferzone" , "Mobile" , "Tower" , "Clifton" , "Sakhi Hassan","Bufferzone"]
    
    let emails = ["imran@gmail.com","kashan@gmail.com","saad@gmail.com","omer@gmail.com","saad@gmail.com","saad@gmail.com"]
    let contacts = ["03322312649","03322312649","03322312649","03322312649","03322312649","03322312649"]
    let users = ["Imran","Syed Kashan","Saad Zafar","Omer Asif","Saad Zafar","Saad Zafar"]
    let time = ["23,Mar 14:45","23,Mar 14:45","23,Mar 14:45","23,Mar 14:45","23,Mar 14:45","23,Mar 14:45"]
    
    let images:[UIImage] = [
        UIImage(named: "candle.jpg")!,
        UIImage(named: "cup.jpeg")!,
           UIImage(named: "vase.jpeg")!,
             UIImage(named: "lamp.jpeg")!,
        UIImage(named: "chair.jpeg")!,
     UIImage(named: "icons8-airplane-landing-50")!
    ]
    var profileImages = [UIImage]()    //MARK: - Outlets
    
    @IBOutlet weak var txt_search: SkyFloatingLabelTextField!
    @IBOutlet weak var table: UITableView!
    //MARK: - View life cycle
    override func viewDidLoad() {
    super.viewDidLoad()
        for i in emails{
            profileImages.append(UIImage(named: i)!)
        }
    
    // Do any additional setup after loading the view.
        self.table.delegate = self
        self.table.dataSource = self
        self.table.tableFooterView = UIView()
        self.txt_search.inputView = pickerView
        pickerView.delegate = self
        
        
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(refreshfun(sender:)), for: UIControl.Event.valueChanged)
        table.addSubview(refreshControl)
        
     
        helper.sharedInstance.getAdsResponseFromFirebase(view : self.view)
        
   
        table.reloadData()
        

}
    
    override func viewWillAppear(_ animated: Bool) {
        table.reloadData()
     
    }
    //MARK: - Actions
    
    @IBAction func btn_SearchAction(_ sender: Any) {
        searched = true
        searchedCategory = txt_search.text!
    }
    //MARK: - Functions
    
    @objc func refreshfun(sender:AnyObject) {
  helper.sharedInstance.getAdsResponseFromFirebase(view: self.view)
        table.reloadData()
        sender.endRefreshing()
    }
    
    func showPopUpWithImageUrl(title:String,Desc:String,Demand:String,email:String,Contact:String, image1:String,image2:String ,image3:String, time : String , profilePic : String ,UserName: String , location : String)
    {   helper.sharedInstance.setImageWithSDWebImage(imageView: popUpView.img_image1, url: image1)
        helper.sharedInstance.setImageWithSDWebImage(imageView: popUpView.img_image2, url: image2)
        helper.sharedInstance.setImageWithSDWebImage(imageView: popUpView.img_image3, url: image3)
        helper.sharedInstance.setImageWithSDWebImage(imageView: popUpView.img_UserProfilePic, url: profilePic)
        self.showPopUp(title: title, Desc: Desc, Demand: Demand, email: email, Contact: Contact, time: time, UserName: UserName, location: location)
        self.popUpView.Btn_Add.isEnabled = false
        self.popUpView.Btn_Add.alpha = 0.4
        
        
      
        
    }
    
    func showPopUpWithImage(title:String,Desc:String,Demand:String,email:String,Contact:String, image1:UIImage,image2:UIImage ,image3:UIImage, time : String , profilePic : UIImage ,UserName: String , location : String){
        self.popUpView.img_image1.image = image1
           self.popUpView.img_image2.image = image2
           self.popUpView.img_image3.image = image3
           self.popUpView.img_UserProfilePic.image = profilePic
          self.showPopUp(title: title, Desc: Desc, Demand: Demand, email: email, Contact: Contact, time: time, UserName: UserName, location: location)
    }
    
    
    
    func showPopUp(title:String,Desc:String,Demand:String,email:String,Contact:String, time : String ,UserName: String , location : String){
        self.popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        
        self.popUpView.lbl_contact.text = Contact
        
        
        self.popUpView.lbl_desc.text = Desc
        self.popUpView.lbl_price.text = Demand
        self.popUpView.lbl_title.text = title
        self.popUpView.lbl_UserEmail.text = email
        self.popUpView.lbl_time.text = time
        
        self.popUpView.lbl_location.text = location
        self.popUpView.lbl_UserName.text = UserName
        
        
        self.popUpView.titleView.layer.maskedCorners = [.layerMaxXMinYCorner,.layerMinXMinYCorner]
        
        
        self.popUpView.titleView.cornerRadius = 12
        self.popUpView.AdPicView.cornerRadius = 12
        self.popUpView.img_UserProfilePic.cornerRadius = self.popUpView.img_UserProfilePic.bounds.size.width * 0.5
        
        self.popUpView.cancel.addTarget(self, action: #selector(self.dismissDialogue(_:)), for: .touchUpInside)
        
        self.popUpView.Btn_Add.addTarget(self, action: #selector(self.showInAR(_:)), for: .touchUpInside)
        
        self.popUpView.satus_View.clipsToBounds = true
        self.popUpView.satus_View.cornerRadius = self.popUpView.satus_View.bounds.size.width * 0.5
        self.popUpView.satus_View.backgroundColor = UIColor.green
        self.view.addSubview(self.popUpView)
        
    }
    
    @objc func dismissDialogue(_ sender: UIButton)
    {
        self.popUpView.removeFromSuperview()
    }
    
    @objc func showInAR(_ sender: UIButton)
    {
       let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainViewController")  as! MainViewController
        self.present(vc, animated: true, completion: nil)
    }
    
  
    

}
//MARK: - Extensions

extension MainPageViewController:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.titles.count  + helper.sharedInstance.allAds.count)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tableViewCellControllerTableViewCell") as! tableViewCellControllerTableViewCell
        if(indexPath.row < self.titles.count)
        {
        
        cell.lbl_title.text = self.titles[indexPath.row]
        cell.lbl_desc.text = self.descr[indexPath.row]
        cell.lbl_price.text = self.prices[indexPath.row]
        cell.img_image.image = self.images[indexPath.row]
        cell.img_ProfilePic.image =  self.profileImages[indexPath.row]
        cell.lbl_UserName.text = self.users[indexPath.row]
        cell.lbl_userEmail.text = self.emails[indexPath.row]
        cell.lbl_time.text = self.time[indexPath.row]
        cell.staus_View.backgroundColor = UIColor.green
        }
        else{
             let ad = helper.sharedInstance.allAds[indexPath.row - self.titles.count]
            
            cell.lbl_title.text = ad.title
            cell.lbl_desc.text = ad.desc
            cell.lbl_price.text = ad.demand
               helper.sharedInstance.setImageWithSDWebImage(imageView: cell.img_image, url: ad.pic3)
            helper.sharedInstance.setImageWithSDWebImage(imageView: cell.img_ProfilePic, url: ad.profilePic)
            cell.lbl_UserName.text = ad.userName
            cell.lbl_userEmail.text = ad.email
            cell.lbl_time.text = ad.time
            if(ad.status){
                cell.staus_View.backgroundColor = UIColor.green}
            else{
                cell.staus_View.backgroundColor = UIColor.clear
            }
            
        }
    return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 280
        
   
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
           tableView.deselectRow(at: indexPath, animated: true)
         helper.sharedInstance.selected_AR = indexPath.row
        
        if(indexPath.row < self.titles.count){
        UIView.animate(withDuration: 0.4, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: {
            
           
            self.showPopUpWithImage(title:  self.titles[indexPath.row], Desc: self.descr[indexPath.row], Demand: "Rs" + self.prices[indexPath.row], email: self.emails[indexPath.row], Contact: self.contacts[indexPath.row], image1: self.images[indexPath.row], image2: self.images[indexPath.row], image3: self.images[indexPath.row], time: self.time[indexPath.row], profilePic: self.profileImages[indexPath.row], UserName: self.users[indexPath.row], location: self.locations[indexPath.row])
            
            self.view.layoutIfNeeded()
        }, completion: nil)
        }
        
        
        else{
            UIView.animate(withDuration: 0.4, delay: 0.0, options: UIView.AnimationOptions.curveEaseOut, animations: {
                
                let ad = helper.sharedInstance.allAds[indexPath.row - self.titles.count]
                
                self.showPopUpWithImageUrl(title:  ad.title, Desc: ad.desc,
                    Demand: "Rs" + ad.demand,
                    email: ad.email,
                    Contact: ad.contact,
                    image1: ad.pic1,
                    image2: ad.pic2,
                    image3: ad.pic3,
                    time: ad.time,
                    profilePic: ad.profilePic ,
                    UserName: ad.userName,
                    location: ad.location)
                
                self.view.layoutIfNeeded()
            }, completion: nil)
        }

    }//didSelectRowAt
    
    
}//extension

extension MainPageViewController: UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return  1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return helper.sharedInstance.categories.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return helper.sharedInstance.categories[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        txt_search.text = helper.sharedInstance.categories[row]
    }
    
    
}

