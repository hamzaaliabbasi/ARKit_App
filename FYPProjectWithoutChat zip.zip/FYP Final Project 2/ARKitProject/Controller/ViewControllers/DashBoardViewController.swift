//
//  DashBoardViewController.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 14/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import SWRevealViewController


class DashBoardViewController: UIViewController {

    
    @IBOutlet weak var firstView:UIView?
    @IBOutlet weak var secondView:UIView?
     @IBOutlet weak var thirdView:UIView?
    
    @IBOutlet weak var MenuButton: UIBarButtonItem!
    
    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        firstView?.alpha =  1
        secondView?.alpha = 0
        thirdView?.alpha = 0
        
        //SWReaveal
        
        if self.revealViewController() != nil {
//            let menu = UIBarButtonItem()
//            menu.target = self.revealViewController()
            MenuButton.target = self.revealViewController()
            MenuButton.action =  #selector(SWRevealViewController.revealToggle(_:))
            
            //self.navigationItem.title = "Home"
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
           
            
            
            
        }

        
        
    }
    //MARK: Actions
    @IBAction func segment(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            let vc = self.childViewControllers[0] as! MainPageViewController
            vc.viewWillAppear(true)
            firstView?.alpha =  1
            secondView?.alpha = 0
            thirdView?.alpha = 0
        
          
        case 1:
            firstView?.alpha =  0
            secondView?.alpha = 1
        thirdView?.alpha = 0
            
        case 2:
            
            firstView?.alpha =  0
            secondView?.alpha = 0
            thirdView?.alpha =  1
            
        default:
            return
        }
    }

  
}
