//
//  MyAdsViewController.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 30/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit


class MyAdsViewController: UIViewController {

      //MARK: - Global Variables
    
    var refreshControl = UIRefreshControl()
    var popUpView = popOn.instanceFromNib()
    var curIndex : Int = 0
    
    // MARK: - Outlets
    
    @IBOutlet weak var lbl_addNotposted: UILabel!
    @IBOutlet weak var Menu: UIBarButtonItem!
    @IBOutlet weak var table: UITableView!
    
    
    //MARK: - ViewLifeCycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.view.bringSubview(toFront: self.lbl_addNotposted)
        
        if(helper.sharedInstance.myAds.count == 0)
        {self.lbl_addNotposted.isHidden = false}
        else{
            self.lbl_addNotposted.isHidden = true
        }
        
        //SWReaveal
        
        if self.revealViewController() != nil {
            Menu.target = self.revealViewController()
            Menu.action =  #selector(SWRevealViewController.revealToggle(_:))
        
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
            
            }//swreveal
        
        self.table.tableFooterView = UIView()
    }
    
      //MARK: - Actions
    

    //MARK: - Functions
    
    @objc func refreshfun(sender:AnyObject) {
        helper.sharedInstance.getAdsResponseFromFirebase(view: self.view)
        table.reloadData()
        sender.endRefreshing()
    }
    
    func showPopUpWithImageUrl(title:String,Desc:String,Demand:String,email:String,Contact:String, image1:String,image2:String ,image3:String, time : String , profilePic : String ,UserName: String , location : String)
    {   helper.sharedInstance.setImageWithSDWebImage(imageView: popUpView.img_image1, url: image1)
        helper.sharedInstance.setImageWithSDWebImage(imageView: popUpView.img_image2, url: image2)
        helper.sharedInstance.setImageWithSDWebImage(imageView: popUpView.img_image3, url: image3)
        helper.sharedInstance.setImageWithSDWebImage(imageView: popUpView.img_UserProfilePic, url: profilePic)
        self.showPopUp(title: title, Desc: Desc, Demand: Demand, email: email, Contact: Contact, time: time, UserName: UserName, location: location)
        
        
        
    }
    
    func showPopUpWithImage(title:String,Desc:String,Demand:String,email:String,Contact:String, image1:UIImage,image2:UIImage ,image3:UIImage, time : String , profilePic : UIImage ,UserName: String , location : String){
        self.popUpView.img_image1.image = image1
        self.popUpView.img_image2.image = image2
        self.popUpView.img_image3.image = image3
        self.popUpView.img_UserProfilePic.image = profilePic
        self.showPopUp(title: title, Desc: Desc, Demand: Demand, email: email, Contact: Contact, time: time, UserName: UserName, location: location)
    }
    
    
    
    func showPopUp(title:String,Desc:String,Demand:String,email:String,Contact:String, time : String ,UserName: String , location : String){
        self.popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        
        
        self.popUpView.lbl_contact.text = Contact
        
        
        self.popUpView.lbl_desc.text = Desc
        self.popUpView.lbl_price.text = Demand
        self.popUpView.lbl_title.text = title
        self.popUpView.lbl_UserEmail.text = email
        self.popUpView.lbl_time.text = time
        
        self.popUpView.lbl_location.text = location
        self.popUpView.lbl_UserName.text = UserName
        
        
        self.popUpView.titleView.layer.maskedCorners = [.layerMaxXMinYCorner,.layerMinXMinYCorner]
        
        
        self.popUpView.titleView.cornerRadius = 12
        self.popUpView.AdPicView.cornerRadius = 12
        self.popUpView.img_UserProfilePic.cornerRadius = self.popUpView.img_UserProfilePic.bounds.size.width * 0.5
        
        self.popUpView.cancel.addTarget(self, action: #selector(self.dismissDialogue(_:)), for: .touchUpInside)
        
        self.popUpView.Btn_Add.addTarget(self, action: #selector(self.showInAR(_:)), for: .touchUpInside)
        
        self.popUpView.satus_View.clipsToBounds = true
        self.popUpView.satus_View.cornerRadius = self.popUpView.satus_View.bounds.size.width * 0.5
        self.popUpView.satus_View.backgroundColor = UIColor.green
        self.view.addSubview(self.popUpView)
        
    }
    
    @objc func dismissDialogue(_ sender: UIButton)
    {
        self.popUpView.removeFromSuperview()
    }
    
    @objc func showInAR(_ sender: UIButton)
    {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainViewController")  as! MainViewController
        self.present(vc, animated: true, completion: nil)
    }
    
    
    @objc func edit(_ sender: UIButton){
         helper.sharedInstance.curAdForEdit = sender.tag
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EditMyAdViewController") as! EditMyAdViewController
     
        self.navigationController!.pushViewController(vc, animated: true)
        
    }
    @objc func deleteBtn(_ sender: UIButton){
        let Alert = UIAlertController(title: "Delete", message: "Are you sure that you want to delete this ad?", preferredStyle: .alert)
        
        
        let alert_Action = UIAlertAction(title: "Confirm", style: .default, handler: {(alert: UIAlertAction!) in
            
          helper.sharedInstance.myAds.remove(at: self.curIndex)
            self.table.reloadData()
//            helper.sharedInstance.deleteFromFirebase(row: self.curIndex)
           
            
            })//handler
        
        Alert.addAction(alert_Action)
        Alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        self.present(Alert, animated: true, completion: nil)
        
    }
    
    
    
    
}//Class Ends

  //MARK: - Extensions


extension MyAdsViewController:UITableViewDelegate,UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return helper.sharedInstance.myAds.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
     
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyAdsTableViewCell") as! MyAdsTableViewCell
        
        let ad = helper.sharedInstance.myAds[indexPath.row]
        cell.lbl_desc.text = ad.desc
        cell.lbl_UserName.text = ad.userName
        cell.lbl_userEmail.text = ad.email
        cell.lbl_title.text = ad.time
        cell.lbl_price.text = ad.demand
        cell.lbl_time.text = ad.time
        if(ad.status == false)
        {
            cell.staus_View.isHidden = true
        }
        cell.btn_Edit.tag = indexPath.row
        cell.btn_Delete.tag  = indexPath.row
        cell.btn_Delete.addTarget(self, action: #selector(self.deleteBtn(_:)), for: .touchUpInside)
        cell.btn_Edit.addTarget(self, action: #selector(self.edit(_:)), for: .touchUpInside)
        helper.sharedInstance.setImageWithSDWebImage(imageView: cell.img_image, url: ad.pic3)
        helper.sharedInstance.setImageWithSDWebImage(imageView: cell.img_ProfilePic, url: ad.profilePic)
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
         tableView.deselectRow(at: indexPath, animated: true)
        self.curIndex = indexPath.row
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 330
    }
    
    
    
}

