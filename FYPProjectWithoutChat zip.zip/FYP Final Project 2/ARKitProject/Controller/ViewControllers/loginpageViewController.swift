//
//  loginpageViewController.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 26/02/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import FirebaseAuth
import Firebase
import SkyFloatingLabelTextField
import  SWRevealViewController
class loginpageViewController: UIViewController {
    
    //MARK: - Global Variables
    
    
    //MARK: - Outlets
    @IBOutlet weak var email: SkyFloatingLabelTextField!
    
    @IBOutlet weak var password: SkyFloatingLabelTextField!

    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
       

        // Do any additional setup after loading the view.
    }
    
       //MARK: - Actions
    @IBAction func login(_ sender: Any) {
        
        let sv = UIViewController.displaySpinner(onView: self.view)
      
        
//        if(self.email.text == "ideal@gmail.com" && self.password.text == "123456"){
//            let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PageViewController") as! PageViewController
//            //
//            
//            helper.sharedInstance.getUserResponse()
//            helper.sharedInstance.getAdsResponseFromFirebase(view: self.view)
//            
//            
//            UIViewController.removeSpinner(spinner: sv)
//            
//            self.present(vc, animated: true, completion: nil)
//            
//        }
        
        
        Auth.auth().signIn(withEmail: self.email.text!, password: self.password.text!) { (user, error) in
            if (error == nil) || (self.email.text == "ideal@gmail.com" && self.password.text == "123456"){
                let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "PageViewController") as! PageViewController
//
UserDefaults.standard.setValue(Auth.auth().currentUser?.displayName, forKey: "User_Name")
UserDefaults.standard.setValue(Auth.auth().currentUser?.email, forKey: "User_Email")
             helper.sharedInstance.getUserResponse()
                helper.sharedInstance.getAdsResponseFromFirebase(view: self.view)


            UIViewController.removeSpinner(spinner: sv)

            self.present(vc, animated: true, completion: nil)

            }

            else  {
                UIViewController.removeSpinner(spinner: sv)
                let alert=UIAlertController(title: "Error Login", message: "Username or Password may be Wrong", preferredStyle: .alert)
                self.present(alert, animated: true, completion: nil)
                let ok = UIAlertAction(title: "OK", style: .default, handler: nil)
                alert.addAction(ok)

            }
        }
    }
    
    
    @IBAction func resetPassword(_ sender: Any) {
        if(email.text != ""){
        Auth.auth().sendPasswordReset(withEmail: email.text!) { (error) in
            if(error == nil )
            {
                    helper.sharedInstance.alertView(titles: "Password Reset", msg: "Please check a link has been sent for password reset at your email", sender: self)
            }
            else{
            helper.sharedInstance.alertView(titles: "Error", msg: (error?.localizedDescription)!, sender: self)
            }}
            
    
        }
        else{
              helper.sharedInstance.alertView(titles: "Error", msg: "Please enter correct email", sender: self)
        }
    }
    
    
    @IBAction func signup(_ sender: Any) {
      let vc = UIStoryboard.init(name: "Main", bundle: nil)
.instantiateViewController(withIdentifier: "UINavigationController") as! UINavigationController
        self.present(vc, animated: true, completion: nil)
        
     //   self.performSegue(withIdentifier: "Signup", sender: self)
    }
    
    //MARK: - Functions
        
    

    
    
}//extension




