//
//  Signup.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 26/02/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import SkyFloatingLabelTextField


class Signup: UIViewController {
    //MARK: - Global Variables
    
     let imagePicker = UIImagePickerController()
    var sv = UIView()
    //MARK: - Outlets

    @IBOutlet weak var txt_name: SkyFloatingLabelTextField!
    @IBOutlet weak var txt_email: SkyFloatingLabelTextField!
    @IBOutlet weak var txt_password: SkyFloatingLabelTextField!
   @IBOutlet weak var txt_contact: SkyFloatingLabelTextField!
    @IBOutlet weak var txt_address: SkyFloatingLabelTextField!
    
    @IBOutlet weak var progilePicCardView: UIView!
    @IBOutlet weak var imageView: UIImageView!
    
    //MARK: - ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hideKeyboardWhenTappedAround()
        imagePicker.delegate = self
        progilePicCardView.cornerRadius = progilePicCardView.bounds.size.height * 0.5
        
    }
    
    //MARK: - Actions
    @IBAction func SignUp(_ sender: Any) {
      
        
        if ( self.txt_email?.text == "" || self.txt_password?.text == "")
        {self.alertMsg(userMessage: "You can't let any field to remain empty")}
            
        else if(self.txt_password.text!.count < 6)
        {self.alertMsg(userMessage: "Password length should be greater than 5")
        }
            
        else
        {createAccountForAuthentication()
            
        }
    }
    
    @IBAction func Back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func uploadImage(_ sender: Any) {
            present(imagePicker, animated: true, completion: nil)
    }
    
    //MARK: - Functions
    
    
    func createAccountForAuthentication(){
        Auth.auth().createUser(withEmail: self.txt_email.text!, password: self.txt_password.text!, completion: { (user, error) in
            self.sv = UIViewController.displaySpinner(onView: self.view)
            if error == nil{
              
                self.CreateUserProfile()
                
                
            }
                
            else{ if let error = error {
                UIViewController.removeSpinner(spinner: self.sv)
                if let errCode = AuthErrorCode(rawValue: error._code) {
                    switch errCode {
                    case .invalidEmail:
                        self.createAlerterror(
                            title: "Error",message:"\(error.localizedDescription)")
                    case .emailAlreadyInUse:
                        self.createAlerterror(title: "Error" , message: "\(error.localizedDescription)")
                    default:
                        self.createAlerterror(title: "error", message: "\(error.localizedDescription)" )
                    }
                }
                return
                }
                
                
                
            }
        })
        
      
    }
    
    func CreateUserProfile(){
           var ref:DatabaseReference!
        
      
        ref = Database.database().reference().child("user")
        var storageRef = Storage.storage().reference().child(Auth.auth().currentUser!.email!)
       
            let uploadData = UIImageJPEGRepresentation(self.imageView.image!, 0.2)
            let uploadTask = storageRef.putData(uploadData!, metadata: nil) { (metadata, error) in
                
                if(error == nil)
                {
                    
                    storageRef.downloadURL(completion: { (url, error) in
                        if ( error == nil)
                        {
                            if let profileImageUrl = url?.absoluteString {
                              
                                    let a = Auth.auth().currentUser!
                                    let user = [
                                        "Id": a.uid as! String,
                                        "Email" : self.txt_email.text as! String,
                                        "Name" : self.txt_name.text as! String,
                                        "Address" : self.txt_address.text as! String ,
                                        "Image" : profileImageUrl as! String,
                                        "Contact" : self.txt_contact.text as! String
                            
                                        ] as [String : Any]
                                    
                                    
                                    ref.child(a.uid).setValue(user)
                                UIViewController.removeSpinner(spinner: self.sv)
                                    
                                    let myAlert = UIAlertController(title: "Done", message: "Account Created Succdessfully", preferredStyle: UIAlertControllerStyle.alert)
                                myAlert.addAction(UIAlertAction(title: "Okay",
                                                                style: UIAlertActionStyle.default,
                                                              handler: {(alert: UIAlertAction!)  in self.dismiss(animated: true, completion: nil)}))
                               
                                    self.present(myAlert, animated: true, completion: nil)
                               
                            }// if let profileImageUrl
                            
                        }//if error
                    }//closure of download url
                    )//download url
                    
                }//if error
            }// if closure of medta
       
        
    }// function ends
    
    
    func createAlert(title:String, message:String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        //CREATING ON BUTTON
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: { (action) in
            
           self.dismiss(animated: true, completion: nil)
            
        }))
        
        
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    func alertMsg(userMessage:String)
    {
        let myAlert = UIAlertController(title: "Error", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
        myAlert.addAction(okAction)
        present(myAlert, animated: true, completion: nil)
    }
    
    
    func createAlerterror(title:String, message:String)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        
        //CREATING ON BUTTON
        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertAction.Style.default, handler: nil))
        
        
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    
    }
    


extension UIViewController {
    class func displaySpinner(onView : UIView) -> UIView {
        let spinnerView = UIView.init(frame: onView.bounds)
        spinnerView.backgroundColor = UIColor.init(red: 0.5, green: 0.5, blue: 0.5, alpha: 0.5)
        let ai = UIActivityIndicatorView.init(activityIndicatorStyle: .whiteLarge)
        ai.startAnimating()
        ai.center = spinnerView.center
        
        DispatchQueue.main.async {
            spinnerView.addSubview(ai)
            onView.addSubview(spinnerView)
        }
        
        return spinnerView
    }
    
    class func removeSpinner(spinner :UIView) {
        DispatchQueue.main.async {
            spinner.removeFromSuperview()
        }
}



}


//MARK: - Extensions

extension Signup{
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(Signup.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

extension Signup: UIImagePickerControllerDelegate,UINavigationControllerDelegate
{
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let pickedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        //imageView.contentMode = .scaleAspectFit
        
    self.imageView.image = pickedImage
        
        dismiss(animated: true, completion: nil)
    }
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}

