//
//  EditMyAdViewController.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 30/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
import Firebase
import FirebaseDatabase
import FirebaseStorage
import FirebaseAuth

class EditMyAdViewController: UIViewController {
    
    
    //MARK: - Global Variables
    var ad_ID = ""
    var ref:DatabaseReference!
    var images = [UIImageView]()
    let imagePicker = UIImagePickerController()
    let pickerView = UIPickerView()
    var Urls = [String]()
    var status = ["Available","Already Sold"]
       let textField = UITextField.init(frame: CGRect(x: 0, y: 0, width: 0, height: 0))
    
    let imageTakingTypes = ["Gallery","Camera"]
    var picTakingType = 0
    
    //MARK: - Outlets
    
    
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    
    @IBOutlet weak var txt_title: SkyFloatingLabelTextField!
    @IBOutlet weak var txt_desc: SkyFloatingLabelTextField!
    @IBOutlet weak var txt_category: SkyFloatingLabelTextField!
    @IBOutlet weak var txt_condition: SkyFloatingLabelTextField!
    @IBOutlet weak var txt_demand: SkyFloatingLabelTextField!
    
    @IBOutlet weak var txt_status: SkyFloatingLabelTextField!
    
    //MARK: - ViewLifeCycle

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        
        self.initializeField()
        
        imagePicker.delegate = self
        images = [imageView1,imageView2,imageView3]
        textField.inputView = pickerView
        textField.delegate = self
        pickerView.delegate = self
        pickerView.dataSource = self
        txt_category.inputView = pickerView
        txt_category.delegate = self
        txt_condition.inputView = pickerView
        txt_condition.delegate = self
        txt_status.inputView = pickerView
        txt_status.delegate = self
        self.view.addSubview(textField)


    }
    //MARK: - Actions
    
    @IBAction func pickImage(_ sender: Any) {
        
        
        
        pickerView.tag =  2
        textField.becomeFirstResponder()
        
        
        
    }
    

    @IBAction func update(_ sender: Any) {
        
        
        if (imageView1.image != UIImage(named: "add-new-create-plus-insert-append-interface-2503") &&
            imageView2.image != UIImage(named: "add-new-create-plus-insert-append-interface-2503") &&
            imageView3.image != UIImage(named: "add-new-create-plus-insert-append-interface-2503") &&
            txt_title.text != "" &&
            txt_condition.text != "" &&
            txt_demand.text != "" &&
            txt_category.text != "" &&
            txt_desc.text != ""
            )
        {
            self.firebaseAdUpdate()}
            
        else{
            let myAlert = UIAlertController(title: "Error", message: "You must fill all text fields", preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil)
            myAlert.addAction(okAction)
            self.present(myAlert, animated: true, completion: nil)
            
        }
        
        
    }
    
    //MARK: - Functions
    func firebaseAdUpdate(){
        
        
        var stat = true
        if (txt_status.text == status[0])
        {stat = true }
        else{
            stat = false
        }
        
        var noOfAdsAtFirebase = 0
        let sv = UIViewController.displaySpinner(onView: self.view)
        ref = Database.database().reference().child("Ads").child(ad_ID)
        
        var count = 1
        
        for img in images{
            var storageRef = Storage.storage().reference().child("Ad: \(self.ad_ID)").child("Pic:\(count)")
            count += 1
            let uploadData = UIImageJPEGRepresentation(img.image!, 0.0)
            let uploadTask = storageRef.putData(uploadData!, metadata: nil) { (metadata, error) in
                
                if(error == nil)
                {
                    
                    storageRef.downloadURL(completion: { (url, error) in
                        if ( error == nil)
                        {
                            
                            
                            if let profileImageUrl = url?.absoluteString {
                                self.Urls.append(profileImageUrl)
                                
                                if(self.Urls.count == 3){
                                    let a = Auth.auth().currentUser!
                                    let user = [
                                        "Ad_Id" : Int(self.ad_ID) as! Int ,
                                        "Contact" : UserDefaults.standard.value(forKey: "User_Contact") ,
                                        "UserId": a.uid as! String,
                                        "Email": a.email as! String,
                                        "Location" : UserDefaults.standard.value(forKey: "User_Address") as! String ,
                                        "User_Name" : UserDefaults.standard.value(forKey: "User_Name") as! String ,
                                        "Title" : self.txt_title.text as! String,
                                        "Status" : stat as! Bool,
                                        "Condition" : self.txt_condition.text as! String ,
                                        "Image" : ["Pic1" : self.Urls[0] ,
                                                   "Pic2" : self.Urls[1] ,
                                                   "Pic3" : self.Urls[2] ]  as! [String : String],
                                        "Description" : self.txt_desc.text as! String,
                                        "Price" :  self.txt_demand.text as! String,
                                        "Category" : self.txt_category.text as! String,
                                        "Time" : helper.sharedInstance.getCurrentTime() as! String ,
                                        "UserProfilePic" : UserDefaults.standard.value(forKey: "User_ProfilePic") as! String
                                        ] as [String : Any]
                                    
                                    
                                    
                                    self.ref.updateChildValues(user)
                                    
                                    
                                    helper.sharedInstance.myAds[helper.sharedInstance.curAdForEdit].setAddvertise(adId: self.ad_ID , category: self.txt_category.text!, condition: self.txt_condition.text!, title: self.txt_title.text!, desc: self.txt_desc.text!, demand: self.txt_demand.text!, pic1: self.Urls[0], pic2: self.Urls[1], pic3:  self.Urls[2], userId: a.uid as! String, time: helper.sharedInstance.getCurrentTime(), email: a.email as! String, location: UserDefaults.standard.value(forKey: "User_Address") as! String, contact: UserDefaults.standard.value(forKey: "User_Contact") as! String, profilePic: UserDefaults.standard.value(forKey: "User_ProfilePic") as! String, userName:  UserDefaults.standard.value(forKey: "User_Name") as! String , status: stat as! Bool)
                                    
                                    
                                    UIViewController.removeSpinner(spinner: sv)
                                    
                                    let myAlert = UIAlertController(title: "Done", message: "Ad updated  successfully", preferredStyle: UIAlertControllerStyle.alert)
                                    let okAction = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(alert: UIAlertAction!) in
                                        
                                        
                                        
                                        self.navigationController?.popViewController(animated: true)})
                                    myAlert.addAction(okAction)
                                    self.present(myAlert, animated: true, completion: nil)
                                }// url array if
                            }// if let profileImageUrl
                            UIViewController.removeSpinner(spinner: sv)
                        }//if error
                    }//closure of download url
                    )//download url
                    
                }//if error
            }// if closure of medta
        }// for images
        
    }// function ends
    
    
    func initializeField(){
        self.ad_ID = helper.sharedInstance.myAds[helper.sharedInstance.curAdForEdit].adId
        let ad = helper.sharedInstance.myAds[Int(self.ad_ID)! - 1]
        self.txt_category.text = ad.category
        self.txt_condition.text = ad.condition
        self.txt_demand.text = ad.demand
        self.txt_title.text = ad.title
        self.txt_desc.text = ad.desc
        if(ad.status)
        {
            self.txt_status.text = status[0]
        }
        else{
            self.txt_status.text = status[1]
        }
      
        
        helper.sharedInstance.setImageWithSDWebImage(imageView: self.imageView1, url: ad.pic1)
        helper.sharedInstance.setImageWithSDWebImage(imageView: self.imageView2, url: ad.pic2)
        helper.sharedInstance.setImageWithSDWebImage(imageView: self.imageView3, url: ad.pic3)
    }
    
    }//class

//MARK: - Extensions
extension EditMyAdViewController: UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return  1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if(pickerView.tag == 0){
            return helper.sharedInstance.categories.count}
        else if(pickerView.tag == 1){
            return helper.sharedInstance.condition.count
        }
        else if (pickerView.tag == 3){
            return self.status.count
        }
            
        else{
            return self.imageTakingTypes.count
        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        if(pickerView.tag == 0){
            return helper.sharedInstance.categories[row]
        }
        else if (pickerView.tag == 1){
            return helper.sharedInstance.condition[row]
        }
        else if (pickerView.tag == 3){
            return self.status[row]
        }
            
        else{
            return self.imageTakingTypes[row]
        }
        
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if(pickerView.tag == 0){
            txt_category.text =  helper.sharedInstance.categories[row]
        }
        else if (pickerView.tag == 1){
            txt_condition.text = helper.sharedInstance.condition[row]
        }
        else if (pickerView.tag == 3){
            txt_condition.text =  self.status[row]
        }
        else{
            if(row == 0)
            {
                if UIImagePickerController.isSourceTypeAvailable(.photoLibrary) {
                    var imagePicker = UIImagePickerController()
                    imagePicker.delegate = self
                    imagePicker.sourceType = .photoLibrary;
                    imagePicker.allowsEditing = false
                    self.present(imagePicker, animated: true, completion: nil)
                }
            }
            else
            {
                if UIImagePickerController.isSourceTypeAvailable(.camera) {
                    var imagePicker = UIImagePickerController()
                    imagePicker.delegate = self
                    imagePicker.sourceType = .camera;
                    imagePicker.allowsEditing = false
                    self.present(imagePicker, animated: true, completion: nil)
                }
            }
            
        }
        
    }// func ends
    
    
    
    
}// extension ends

extension EditMyAdViewController:UITextFieldDelegate{
    
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == txt_category
        {pickerView.tag = 0}
        else if (textField == txt_condition)
        {
            pickerView.tag = 1
        }
        else if(textField == self.txt_status)
        {
            pickerView.tag = 3
        }
        pickerView.reloadAllComponents()
        return true
}

}
    extension EditMyAdViewController: UIImagePickerControllerDelegate,UINavigationControllerDelegate
    {
        
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
            let pickedImage = info[UIImagePickerControllerOriginalImage] as! UIImage
            //imageView.contentMode = .scaleAspectFit
            
            
            if(imageView1.image == UIImage(named: "add-new-create-plus-insert-append-interface-2503")){
                imageView1.alpha = 1
                imageView1.image = pickedImage
                //    img.contentMode = .scaleAspectFit
            }
            else if(imageView2.image == UIImage(named: "add-new-create-plus-insert-append-interface-2503")){
                imageView2.alpha = 1
                imageView2.image = pickedImage
                //    img.contentMode = .scaleAspectFit
            }
            else if(imageView3.image == UIImage(named: "add-new-create-plus-insert-append-interface-2503")){
                imageView3.alpha = 1
                imageView3.image = pickedImage
                //    img.contentMode = .scaleAspectFit
            }
            
            
            
            
            dismiss(animated: true, completion: nil)
        }
        
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            dismiss(animated: true, completion: nil)
        }
}
    

