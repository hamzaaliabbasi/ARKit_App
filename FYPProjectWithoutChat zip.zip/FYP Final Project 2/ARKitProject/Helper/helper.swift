//
//  helper.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 17/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
import Firebase
import UIKit
import SDWebImage

class helper:NSObject{
    //shared Instance
        static let sharedInstance = helper()
    var selected_AR = Int()
    var curUser = user(name: "", email: "", address: "", profImg: "", Id: "" , contact: "")
    var allAds = [advertise]()
    var allUser = [user]()
    var myAds = [advertise]()
    var curAdForEdit = Int()
    var selected_Category = String()
   
    //Global Variables

    let categories = ["Computer or Mobiles","Furniture","Electronic Items","Car","Bike","Crockery" ]
    let condition = ["New","Slightly Used","Roughly Used","Damaged"]
    //Function
    //Showing Alert
    func alertView(titles: String  , msg: String ,sender : UIViewController ){
    let alert = UIAlertController(title: titles, message:msg, preferredStyle: .alert)
    sender.present(alert, animated: true, completion: nil)
        let ok = UIAlertAction(title: "Okay", style: .default, handler: nil)
    alert.addAction(ok)
    
}
    
    //Mark: - Functions
    func getAdsResponseFromFirebase(view:UIView)
    {
        let  ref = Database.database().reference().child("Ads")
           let sv = UIViewController.displaySpinner(onView: view)
        
        ref.observe(.value, with: {(snapshot) in
            if (snapshot.childrenCount > 0)
            {
                
                
                for user in snapshot.children.allObjects as! [DataSnapshot]
                {let userobj = user.value as? [String:Any]
                    let userId = userobj?["UserId"] as! String
                    let title = userobj?["Title"] as! String
                    let status = userobj?["Status"] as! Bool
                    let description = userobj?["Description"] as! String
                    let contact = userobj?["Contact"] as! String
                    let image = userobj?["Image"] as! [String : String]
                    let demand = userobj?["Price"] as! String
                    let category = userobj?["Category"] as! String
                    let condition = userobj?["Condition"] as! String
                    let time = userobj?["Time"] as! String
                    let address = userobj?["Location"] as! String
                    let email = userobj?["Email"] as! String
                    let userName = userobj?["User_Name"] as! String
                    let userProfilePic = userobj?["UserProfilePic"] as! String
                    let pic1 = image["Pic1"]
                   let pic2 = image["Pic2"]
                     let pic3 = image["Pic3"]
                    let ad_Id = userobj?["Ad_Id"] as! Int
                   
                    if(helper.sharedInstance.allAds.count < ad_Id )
                   {helper.sharedInstance.allAds.append(advertise(adId: String(ad_Id), category: category, condition: condition, title: title, desc: description, demand: demand, pic1: pic1!, pic2: pic2!, pic3: pic3!, userId: userId, time: time , email : email , location : address, contact : contact, profilePic: userProfilePic, userName: userName, status : status))}
                    if(userId == UserDefaults.standard.string(forKey: "User_Id"))
                    {
                        if(helper.sharedInstance.myAds.count == 0 ){
                            helper.sharedInstance.myAds.append(advertise(adId: String(ad_Id), category: category, condition: condition, title: title, desc: description, demand: demand, pic1: pic1!, pic2: pic2!, pic3: pic3!, userId: userId, time: time , email : email , location : address, contact : contact, profilePic: userProfilePic, userName: userName, status : status))
                        }
                        else {
                            var present  = false
                            for ad in helper.sharedInstance.myAds
                            {
                                if(Int(ad.adId) ==  ad_Id)
                                {
                                    present = true
                                }
                            }
                            if(present == false){
                                helper.sharedInstance.myAds.append(advertise(adId: String(ad_Id), category: category, condition: condition, title: title, desc: description, demand: demand, pic1: pic1!, pic2: pic2!, pic3: pic3!, userId: userId, time: time , email : email , location : address, contact : contact, profilePic: userProfilePic, userName: userName, status : status))
                            }
                            
                        }//else
                    }//if userID
                    
                }//for
                
            }//if
        })
        UIViewController.removeSpinner(spinner: sv)
        
    }
    
    func getUserResponse(){
        let  ref = Database.database().reference().child("user")
        
        
        ref.observe(.value, with: {(snapshot) in
            if (snapshot.childrenCount > 0)
            {
                
                for user in snapshot.children.allObjects as! [DataSnapshot]
                {let userobj = user.value as? [String:Any]
                    let userId = userobj?["Id"] as! String
                    let name = userobj?["Name"] as! String
                    let email = userobj?["Email"] as! String
                    let profilePic = userobj?["Image"] as! String
                    let address = userobj?["Address"] as! String
                    let contact = userobj?["Contact"] as! String
                    
                    if(userId == Auth.auth().currentUser?.uid)
                    {
                        helper.sharedInstance.setDefaults(name: name, email: email, id: userId, pic: profilePic, address: address, contact: contact)
                    }
                }//for
                
            }//if
        })
    }
    
    func deleteFromFirebase(row :Int)
{
    let  ref = Database.database().reference().child("Ads")
    ref.child(helper.sharedInstance.myAds[row].adId).removeValue()
    
    }
    
    func setImageWithSDWebImage(imageView:UIImageView, url : String){
//  imageView.sd_setImageWithURL(imageUrl, placeholderImage:)
        imageView.sd_showActivityIndicatorView()
        imageView.sd_setImage(with: URL(string: url))
        imageView.sd_removeActivityIndicator()
    }

    func setDefaults(name:String , email: String ,id:String , pic: String , address: String , contact : String)
    {
        helper.sharedInstance.curUser.setUser(name: name, email: email, address: address, profImg: pic, Id: id, contact: contact)
        
        UserDefaults.standard.set(helper.sharedInstance.curUser.id, forKey: "User_Id")
        UserDefaults.standard.set(helper.sharedInstance.curUser.address, forKey: "User_Address");  UserDefaults.standard.set(helper.sharedInstance.curUser.name, forKey: "User_Name");  UserDefaults.standard.set(helper.sharedInstance.curUser.profileImage, forKey: "User_ProfilePic")
        
        UserDefaults.standard.set(helper.sharedInstance.curUser.contact, forKey: "User_Contact")
        UserDefaults.standard.set(helper.sharedInstance.curUser.email , forKey: "User_Email")
        
    }
    
    
    
    func getCurrentTime() -> String{
        
        let months = ["","Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
        
        let date = Date()
        let calender = Calendar.current
        let components = calender.dateComponents([.year,.month,.day,.hour,.minute,.second], from: date)
        
        let year = (components.year)!
        let month = (components.month)!
        let day = (components.day)!
        let hour = (components.hour)!
        
        let minute = (components.minute)!
        
        print ("\(months[month])" + "," + "\(day)" + "," + "\(year)" + "  " + "\(hour)" + ":" + "\(minute)" )
        
        return ("\(months[month])" + "," + "\(day)" + "," + "\(year)" + "  " + "\(hour)" + ":" + "\(minute)" )
    }
    
}
    
  

