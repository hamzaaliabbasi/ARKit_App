//
//  user.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 18/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation
import UIKit
class user{
    var name:String
    var email:String
    var address:String
    var profileImage:String
    var id:String
    var contact:String
    
    init(name: String , email: String , address: String , profImg : String, Id: String,contact : String) {
        self.name = name
        self.email = email
        self.address = address
        self.profileImage = profImg
        self.id = Id
        self.contact = contact
    }
    
    func setUser(name: String , email: String , address: String , profImg : String, Id: String,contact : String) {
        self.name = name
        self.email = email
        self.address = address
        self.profileImage = profImg
        self.id = Id
            self.contact = contact
    }//func


}//Clss Users


