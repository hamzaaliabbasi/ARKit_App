//
//  Advertisment.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 21/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import Foundation

//MARK: - Class Adevertise

class advertise{
    
    //MARK: - Variables
    var userName : String
    var adId: String
    var category: String
    var condition : String
    var pic1: String
    var pic2 : String
    var pic3: String
    var title: String
    var desc : String
    var demand : String
    var userId: String
    var time: String
    var location : String
    var email : String
    var contact : String
    var profilePic :  String
    var status : Bool
    
    //MARK: - Initializer
    
    init(adId: String, category : String,condition : String, title: String ,  desc: String , demand : String , pic1: String , pic2: String , pic3: String ,userId: String , time: String, email : String , location : String , contact: String , profilePic : String , userName: String, status : Bool) {
        self.adId = adId
        self.category = category
        self.condition = condition
        self.title = title
        self.desc = desc
        self.demand = demand
        self.pic1 = pic1
        self.pic2 = pic2
        self.pic3 = pic3
        self.userId = userId
        self.time = time
        self.email = email
        self.location = location
        self.contact = contact
        self.profilePic = profilePic
        self.userName = userName
        self.status = status
    }
    
    //MARK: - Functions
    
    func setAddvertise(adId: String, category : String,condition : String, title: String ,  desc: String , demand : String , pic1: String , pic2: String , pic3: String ,userId: String , time: String, email : String , location : String , contact: String , profilePic : String , userName: String , status : Bool) {
        self.adId = adId
        self.category = category
        self.condition = condition
        self.title = title
        self.desc = desc
        self.demand = demand
        self.pic1 = pic1
        self.pic2 = pic2
        self.pic3 = pic3
        self.userId = userId
        self.time = time
        self.email = email
        self.location = location
        self.contact = contact
        self.profilePic = profilePic
        self.userName = userName
        self.status = status
    }//func
    
    
}//class Advertise
