//
//  tableViewCellControllerTableViewCell.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 13/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class tableViewCellControllerTableViewCell: UITableViewCell {

    
    //MARK: - Oulets
    
    @IBOutlet weak var img_image: UIImageView!
    @IBOutlet weak var lbl_userEmail: UILabel!
    @IBOutlet weak var lbl_UserName: UILabel!
    @IBOutlet weak var img_ProfilePic: UIImageView!
    @IBOutlet weak var lbl_time: UILabel!
    @IBOutlet weak var lbl_title:UILabel!
    @IBOutlet weak var lbl_desc:UILabel!
    @IBOutlet weak var lbl_price:UILabel!
    
    @IBOutlet weak var staus_View: CardMaterialView!
    //MARK: - Awake from Nib
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        img_ProfilePic.clipsToBounds = true
        img_ProfilePic.cornerRadius = img_ProfilePic.bounds.size.width * 0.5
        staus_View.clipsToBounds = true
        staus_View.cornerRadius = staus_View.bounds.size.width * 0.5
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
