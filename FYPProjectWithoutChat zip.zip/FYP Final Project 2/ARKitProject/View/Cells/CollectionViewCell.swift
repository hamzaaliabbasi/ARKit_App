//
//  CollectionViewCell.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 31/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lbl_category: UILabel!
    @IBOutlet weak var img_image: UIImageView!
}
