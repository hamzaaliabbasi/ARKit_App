//
//  popOn.swift
//  ARKitProject
//
//  Created by Fahad Mirza on 13/07/2019.
//  Copyright © 2019 Apple. All rights reserved.
//
import UIKit

class popOn: UIView {
    
    
    
    @IBOutlet weak var lbl_time: UILabel!
    @IBOutlet weak var lbl_UserName: UILabel!
    @IBOutlet weak var img_UserProfilePic: UIImageView!
    @IBOutlet weak var Btn_Add: UIButton!
    @IBOutlet weak var lbl_desc: UILabel!
    @IBOutlet weak var lbl_title: UILabel!
    @IBOutlet weak var  lbl_price: UILabel!
    @IBOutlet weak var  lbl_contact: UILabel!
    @IBOutlet weak var  lbl_UserEmail: UILabel!
    @IBOutlet weak var  img_image1 : UIImageView!
     @IBOutlet weak var  img_image2 : UIImageView!
    @IBOutlet weak var  img_image3:  UIImageView!
    @IBOutlet weak var AdPicView: UIView!
    @IBOutlet weak var titleView: UIView!
    @IBOutlet var cancel: UIButton!
    @IBOutlet weak var lbl_location: UILabel!
    
    @IBOutlet weak var satus_View: CardMaterialView!
    class func instanceFromNib() -> popOn {
        
        return UINib(nibName: "popOn", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! popOn
    }
    
    
}
